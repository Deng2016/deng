#!/usr/bin/env python
# coding:utf-8
"""功能简要说明
作者：dengqingyong
邮箱：yu12377@163.com
时间：2018/5/4 09:00
"""
from deng.mailTool import MailTool

# 实例化邮件对象
mail = MailTool(send_username='it_dqy@qq.com', send_password='cbigecel@qq', send_smtp='stmp.qq.com', echo=True)

# 发送邮件
mail.send(receiver='yu12377@163.com', subject='上线记录', content='table.html', echo=True)
